# Simple Website Template

## Files
- index.html
- style.css

## Run
Open `index.html` in any web browser.

## Customize
Replace the website name, text, email address and sections with your own content.
